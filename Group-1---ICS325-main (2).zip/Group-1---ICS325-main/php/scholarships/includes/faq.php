```php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - Scholarship Finder</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="index.html">Scholarship Finder</a>

        <div class="navbar-nav ms-auto">
            <a class="nav-link" href="index.html">Home</a>
            <a class="nav-link" href="scholarships.php">Scholarships</a>
            <a class="nav-link" href="about.php">About</a>
            <a class="nav-link active" href="faq.php">FAQ</a>
            <a class="nav-link" href="contact.php">Contact</a>
        </div>
    </div>
</nav>

<header class="bg-light py-5">
    <div class="container text-center">
        <h1>Frequently Asked Questions</h1>
        <p class="lead">Find answers to common questions.</p>
    </div>
</header>

<main class="container py-5">

    <div class="mb-4">
        <h2>1. What is Scholarship Finder?</h2>
        <p>
            Scholarship Finder helps students find scholarship opportunities.
        </p>
    </div>

    <div class="mb-4">
        <h2>2. How can I find scholarships?</h2>
        <p>
            Visit the Scholarships page to view available scholarship information.
        </p>
    </div>

    <div class="mb-4">
        <h2>3. Can every student apply for every scholarship?</h2>
        <p>
            No. Each scholarship may have different requirements.
            Read the requirements before applying.
        </p>
    </div>

    <div class="mb-4">
        <h2>4. Does Scholarship Finder give out scholarships?</h2>
        <p>
            No. The website helps students find opportunities.
            Scholarship providers decide who receives awards.
        </p>
    </div>

    <div class="mb-4">
        <h2>5. How can I contact the team?</h2>
        <p>
            Visit the Contact page and send us a message.
        </p>
    </div>

</main>

<footer class="bg-dark text-white text-center py-3">
    <p class="mb-0">Scholarship Finder</p>
</footer>

</body>
</html>
```
